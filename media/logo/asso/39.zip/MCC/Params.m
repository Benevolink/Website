% params motor
k=0.5;
tau=0.01;

A=[0 1;0 -1/tau];
B=[0;k/tau];
C_Theta=[1 0];
C_Omega=[0 1];
D=0;
C_Total=eye(2);
D_Total=[0;0];

% param simu
ti=0;
tf=0.1;
