% Clear
clear all;
clc;

% Params
Params;

% Analyse
Analysis;

% Feedback Design
LinearStateFeedbackDesign;

% Launch Simu
mysys='MCCStateFeedback';
open_system(mysys);
set_param(mysys,'StartTime','ti','StopTime','tf');
out = sim(mysys, 'ReturnWorkspaceOutputs', 'on');
pause(2);
%save_system(mysys);
close_system(mysys);
pause(3);

% Affichage
Plot;