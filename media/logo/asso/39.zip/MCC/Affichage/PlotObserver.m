t=out.t;
x1=out.x(:,1);
x2=out.x(:,2);
x1chap=out.xchap(:,1);
x2chap=out.xchap(:,2);
y=out.y;
ychap=out.ychap;
ey=out.ey;
u=out.u;

figure(1);
subplot(411), 
plot(t,x1,'b',t,x1chap,'r'), grid
xlabel('$t$ (s)','Interpreter','latex'), ylabel('$x_1,\hat x_1$','Interpreter','latex')

subplot(412), 
plot(t,x2,'b',t,x2chap,'r'), grid
xlabel('$t$ (s)','Interpreter','latex'), ylabel('$x_2,\hat x_2$','Interpreter','latex')


subplot(413), 
plot(t,ey,'r'), grid
xlabel('$t$ (s)','Interpreter','latex'), ylabel('$e_y$','Interpreter','latex')

subplot(414), 
plot(t,u,'r'), grid
xlabel('$t$ (s)','Interpreter','latex'), ylabel('$u$ (V)','Interpreter','latex')
