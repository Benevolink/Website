t=out.t;
x1=out.x(:,1);
x2=out.x(:,2);
u=out.u;

figure(1);
subplot(211), 
plot(t,x1,'b',t,x2,'r'), grid
xlabel('$t$ (s)','Interpreter','latex'), ylabel('$\theta$ (rad), $\dot \theta $ (rad/s)','Interpreter','latex')

subplot(212), 
plot(t,u,'r'), grid
xlabel('$t$ (s)','Interpreter','latex'), ylabel('$u$ (V)','Interpreter','latex')
