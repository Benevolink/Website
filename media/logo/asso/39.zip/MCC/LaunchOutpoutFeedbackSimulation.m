% Clear
clear all;
clc;

% Params
Params;

% Analyse
Analysis;

% Feedback Design
LinearStateFeedbackDesign;

% Observer Design
LinearObserverDesign;

% Launch Simu
mysys='MCCOutputFeedback';
open_system(mysys);
set_param(mysys,'StartTime','ti','StopTime','tf');
out = sim(mysys, 'ReturnWorkspaceOutputs', 'on');
pause(2);
save_system(mysys);
close_system(mysys);
pause(3);

% Affichage
PlotObserver;