%PolyCarac=charpoly(A,'x'); %use sym
PolyCarac=poly(A); %do not use sym
a0=PolyCarac(3);
a1=PolyCarac(2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Selection of the closed loop dynamics %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% In order to select zeta: 0.7<zeta<1 eventually > 1 (for observer) in that case gives poles directly it is easier !
% if 0.4 <zeta<0.7 then tr=5/wn; 
% if zeta =0.7 then tr=2.9/wn 
% if zeta<1 then tr=4.3*zeta/wn
% if zeta > 1.5 tr=6*zeta/wn ....
z=0.7;
tr= 3*tau;%tr en BO =3*tau
wn=2.9/(tr);
polyBF=[1 2*z*wn wn*wn];
poles=roots(polyBF);
a0prime=wn^2;
a1prime=2*z*wn;

%% State feedback gain
K=place(A,B,poles);

%% Reference gain
C=C_Theta;
G=-1/(C*(A-B*K)^(-1)*B)