%%%%%%%%%%%%%%%%%%%%%%%%
%% Open Loop Analysis %%
%%%%%%%%%%%%%%%%%%%%%%%%
%% Openloop dynamics
disp(['Eigenvalues of A (open-loop dynamics) are :']);
EigenVals=eig(A)

% compute open loop dynamics
%tol= 3/abs(EigenVals(1));%3/min(abs(EigenVals(1)),abs(EigenVals(2)),abs(EigenVals(3)),abs(EigenVals(4)));

%% Controllability
display('Controllability:')
CAB=ctrb(A,B)
disp(['Rank of Controllability matrix CAB is ',num2str(rank(CAB))]);
disp(['Eigenvalues of Controllability matrix CAB are :']);
eig(CAB)
disp(['Condition number of Controllability matrix CAB is ',num2str(cond(CAB))]);

%% Observability
D=[0];
% measured output: angular position
        % Cf. params C_Theta=[1 0];
        display('Observability (output is angular position (theta)):')
        OAC=obsv(A,C_Theta)
        disp(['Rank of Observability matrix OAC (w.r.t output theta) is ',num2str(rank(OAC))]);
        disp(['Eigenvalues of Observability matrix OAC are :']);
        eig(OAC)
        disp(['Condition number of Observability matrix OAC is ',num2str(cond(OAC))]);
% measured output: angular speed
        % Cf. Params C_Omega=[0 1];
        display('Observability (output is angular speed (dtheta)):')
        OAC=obsv(A,C_Omega)
        disp(['Rank of Observability matrix OAC (w.r.t output dtheta) is ',num2str(rank(OAC))]);
        disp(['Eigenvalues of Observability matrix OAC are :']);
        eig(OAC)
        disp(['Condition number of Observability matrix OAC is ',num2str(cond(OAC))]);
        
        
