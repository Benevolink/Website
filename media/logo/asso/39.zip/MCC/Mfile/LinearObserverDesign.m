% direct poles selection for the observer
% computation of the poles for placement
% In the params m-file you have to select zeta and tr.
% In order to select zeta: 0.7<zeta<1 eventually > 1 (for observer) in that case gives poles directly it is easier !
% if 0.4 <zeta<0.7 then tr=5/wn; 
% if zeta =0.7 then tr=2.9/wn 
% if zeta<1 then tr=4.3*zeta/wn
% if zeta > 1.5 tr=6*zeta/wn ....
trobs=tau;
zobs=0.7;
wnobs=2.9/trobs;
polyobs=[1 2*zobs*wnobs wnobs*wnobs];
polesobs=roots(polyobs);

%% Observer gain
L=place(A',C',polesobs)'

% l2=wnobs*wnobs
% l1=2*zobs*wnobs-1/tau

% state space matrices for the observer implementation in simulink
A_Obs=A;
B_Obs=[B L];
C_Obs=eye(2);
D_Obs=[0 0;0 0];